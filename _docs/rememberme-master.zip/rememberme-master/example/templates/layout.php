<!doctype html>

<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Remember Me PHP library test</title>
    <meta name="author" content="Gabriel Birke">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css?v=2">
</head>

<body>

<div id="container">
    <header>
        <h1>Remember Me PHP library test</h1>
    </header>

    <div id="main">
        <?php
        // Output generated content
        echo $content;
        ?>
    </div>

    <footer>

    </footer>
</div> <!-- end of #container -->

</body>
</html>