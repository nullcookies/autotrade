<?php
// Demo of how the page could look when you display the info of stolen cookies

?>
<p class="error">Someone else has used your login information to acccess this page!<br>
  <a href="/completelogout">Click here to clear all "Remember me" cookies that exist for this user.</a><br>
  After that, log in with your credentials and check your data.</p>
<p><a href="index.php">To login form</a></p>