
# OrderBookL2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**symbol** | **String** |  | 
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**side** | **String** |  | 
**size** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**price** | **Double** |  |  [optional]



