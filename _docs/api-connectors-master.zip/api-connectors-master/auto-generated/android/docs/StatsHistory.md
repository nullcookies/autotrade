
# StatsHistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | [**Date**](Date.md) |  | 
**rootSymbol** | **String** |  | 
**currency** | **String** |  |  [optional]
**volume** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**turnover** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



