
# Stats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rootSymbol** | **String** |  | 
**currency** | **String** |  |  [optional]
**volume24h** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**turnover24h** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**openInterest** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**openValue** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



