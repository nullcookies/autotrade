
# Leaderboard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**isRealName** | **Boolean** |  |  [optional]
**profit** | **Double** |  |  [optional]



