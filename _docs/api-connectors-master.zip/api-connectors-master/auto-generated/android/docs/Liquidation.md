
# Liquidation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderID** | **String** |  | 
**symbol** | **String** |  |  [optional]
**side** | **String** |  |  [optional]
**price** | **Double** |  |  [optional]
**leavesQty** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



