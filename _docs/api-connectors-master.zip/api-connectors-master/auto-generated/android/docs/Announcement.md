
# Announcement

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**link** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**content** | **String** |  |  [optional]
**date** | [**Date**](Date.md) |  |  [optional]



