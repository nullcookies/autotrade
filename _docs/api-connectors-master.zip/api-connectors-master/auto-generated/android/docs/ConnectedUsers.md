
# ConnectedUsers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**bots** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



