
# IndexComposite

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | [**Date**](Date.md) |  | 
**symbol** | **String** |  |  [optional]
**indexSymbol** | **String** |  |  [optional]
**reference** | **String** |  |  [optional]
**lastPrice** | **Double** |  |  [optional]
**weight** | **Double** |  |  [optional]
**logged** | [**Date**](Date.md) |  |  [optional]



