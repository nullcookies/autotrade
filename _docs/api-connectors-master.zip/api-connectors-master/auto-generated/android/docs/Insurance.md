
# Insurance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **String** |  | 
**timestamp** | [**Date**](Date.md) |  | 
**walletBalance** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



