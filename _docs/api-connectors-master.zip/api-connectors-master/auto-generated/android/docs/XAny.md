
# XAny

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



