
# UserCommission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**makerFee** | **Double** |  |  [optional]
**takerFee** | **Double** |  |  [optional]
**settlementFee** | **Double** |  |  [optional]
**maxFee** | **Double** |  |  [optional]



