
# Chat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**date** | [**Date**](Date.md) |  | 
**user** | **String** |  | 
**message** | **String** |  | 
**html** | **String** |  | 
**fromBot** | **Boolean** |  |  [optional]
**channelID** | **Double** |  |  [optional]



