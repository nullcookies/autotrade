
# InstrumentInterval

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**intervals** | **List&lt;String&gt;** |  | 
**symbols** | **List&lt;String&gt;** |  | 



