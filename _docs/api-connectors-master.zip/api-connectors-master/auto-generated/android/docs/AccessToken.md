
# AccessToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**ttl** | **Double** | time to live in seconds (2 weeks by default) |  [optional]
**created** | [**Date**](Date.md) |  |  [optional]
**userId** | **Double** |  |  [optional]



