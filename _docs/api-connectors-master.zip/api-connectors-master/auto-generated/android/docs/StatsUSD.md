
# StatsUSD

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rootSymbol** | **String** |  | 
**currency** | **String** |  |  [optional]
**turnover24h** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**turnover30d** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**turnover365d** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**turnover** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



