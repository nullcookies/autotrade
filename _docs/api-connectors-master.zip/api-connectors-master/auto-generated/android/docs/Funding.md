
# Funding

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | [**Date**](Date.md) |  | 
**symbol** | **String** |  | 
**fundingInterval** | [**Date**](Date.md) |  |  [optional]
**fundingRate** | **Double** |  |  [optional]
**fundingRateDaily** | **Double** |  |  [optional]



