
# Quote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | [**Date**](Date.md) |  | 
**symbol** | **String** |  | 
**bidSize** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**bidPrice** | **Double** |  |  [optional]
**askPrice** | **Double** |  |  [optional]
**askSize** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



