# IO.Swagger.Model.Stats
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RootSymbol** | **string** |  | 
**Currency** | **string** |  | [optional] 
**Volume24h** | **decimal?** |  | [optional] 
**Turnover24h** | **decimal?** |  | [optional] 
**OpenInterest** | **decimal?** |  | [optional] 
**OpenValue** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

