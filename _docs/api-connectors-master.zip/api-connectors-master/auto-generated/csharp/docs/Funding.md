# IO.Swagger.Model.Funding
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **DateTime?** |  | 
**Symbol** | **string** |  | 
**FundingInterval** | **DateTime?** |  | [optional] 
**FundingRate** | **double?** |  | [optional] 
**FundingRateDaily** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

