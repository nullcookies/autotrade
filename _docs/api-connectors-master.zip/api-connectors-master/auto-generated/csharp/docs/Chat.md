# IO.Swagger.Model.Chat
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **decimal?** |  | [optional] 
**Date** | **DateTime?** |  | 
**User** | **string** |  | 
**Message** | **string** |  | 
**Html** | **string** |  | 
**FromBot** | **bool?** |  | [optional] [default to false]
**ChannelID** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

