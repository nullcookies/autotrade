# IO.Swagger.Model.InstrumentInterval
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Intervals** | **List&lt;string&gt;** |  | 
**Symbols** | **List&lt;string&gt;** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

