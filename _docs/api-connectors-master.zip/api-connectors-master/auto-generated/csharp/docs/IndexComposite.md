# IO.Swagger.Model.IndexComposite
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **DateTime?** |  | 
**Symbol** | **string** |  | [optional] 
**IndexSymbol** | **string** |  | [optional] 
**Reference** | **string** |  | [optional] 
**LastPrice** | **double?** |  | [optional] 
**Weight** | **double?** |  | [optional] 
**Logged** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

