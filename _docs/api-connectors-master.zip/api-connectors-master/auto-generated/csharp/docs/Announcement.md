# IO.Swagger.Model.Announcement
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **decimal?** |  | 
**Link** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**Content** | **string** |  | [optional] 
**Date** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

