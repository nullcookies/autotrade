# IO.Swagger.Model.StatsHistory
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Date** | **DateTime?** |  | 
**RootSymbol** | **string** |  | 
**Currency** | **string** |  | [optional] 
**Volume** | **decimal?** |  | [optional] 
**Turnover** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

