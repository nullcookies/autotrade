# IO.Swagger.Model.Quote
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **DateTime?** |  | 
**Symbol** | **string** |  | 
**BidSize** | **decimal?** |  | [optional] 
**BidPrice** | **double?** |  | [optional] 
**AskPrice** | **double?** |  | [optional] 
**AskSize** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

