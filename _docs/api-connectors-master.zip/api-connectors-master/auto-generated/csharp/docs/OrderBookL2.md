# IO.Swagger.Model.OrderBookL2
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Symbol** | **string** |  | 
**Id** | **decimal?** |  | 
**Side** | **string** |  | 
**Size** | **decimal?** |  | [optional] 
**Price** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

