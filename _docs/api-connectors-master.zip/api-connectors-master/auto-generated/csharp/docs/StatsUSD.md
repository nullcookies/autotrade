# IO.Swagger.Model.StatsUSD
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RootSymbol** | **string** |  | 
**Currency** | **string** |  | [optional] 
**Turnover24h** | **decimal?** |  | [optional] 
**Turnover30d** | **decimal?** |  | [optional] 
**Turnover365d** | **decimal?** |  | [optional] 
**Turnover** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

