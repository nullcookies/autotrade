# IO.Swagger.Model.UserCommission
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MakerFee** | **double?** |  | [optional] 
**TakerFee** | **double?** |  | [optional] 
**SettlementFee** | **double?** |  | [optional] 
**MaxFee** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

