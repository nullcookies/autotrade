#### Node-Request Example

This is a small example of doing [API Key Authentication](https://www.bitmex.com/app/apiKeysUsage)
in combination with the popular [node-request](https://github.com/request/request) module.

