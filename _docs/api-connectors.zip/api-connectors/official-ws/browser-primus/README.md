This is an example of connecting to the Primus endpoint at `/realtimemd`.

Using Primus introduces extra overhead - only use it if you're writing a browser client.

The Primus build is standard - generate a build yourself using primus-multiplex or grab a built client
client [from us](https://www.bitmex.com/api/primus.js).
