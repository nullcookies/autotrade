# PHP Bittrex API Wrapper
An API wrapper class for the Bittrex altcoin exchange platform ([https://bittrex.com/home/api](https://bittrex.com/home/api)).

## Usage
```php
include 'Bittrex.php';

$bittrex = new Bittrex(YOUR_API_KEY, YOUR_API_SECRET);

$markets = $bittrex->GetMarkets();
```

## Documentation
To do.