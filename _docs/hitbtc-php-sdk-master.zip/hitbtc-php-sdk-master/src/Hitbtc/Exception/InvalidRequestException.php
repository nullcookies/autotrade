<?php
namespace Hitbtc\Exception;

class InvalidRequestException extends HitbtcException
{

}
