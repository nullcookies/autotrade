<?php
namespace Hitbtc\Exception;

class HitbtcException extends \Exception
{

}
