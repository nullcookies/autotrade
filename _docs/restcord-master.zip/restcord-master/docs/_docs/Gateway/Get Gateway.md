---
title: Get Gateway
category: Gateway
order: 1
---

# `getGateway`

```php
$client->gateway->getGateway($parameters);
```

## Description

This endpoint does not require authentication.

## Parameters

No Parameters

## Response

Possibly No Response

