---
title: Get Guild Channels
category: Guild
order: 5
---

# `getGuildChannels`

```php
$client->guild->getGuildChannels($parameters);
```

## Description



## Parameters


Name | Type | Required | Default
--- | --- | --- | ---
guild.id | snowflake | true | *null*

## Response

Returns a list of guild channel objects.

Can Return:

* channel
