---
title: Accept Invite
category: Invite
order: 3
---

# `acceptInvite`

```php
$client->invite->acceptInvite($parameters);
```

## Description

This endpoint is deprecated and will be discontinued on March 23, 2018. Add Guild Member should be used in its place.

## Parameters


Name | Type | Required | Default
--- | --- | --- | ---
invite.code | string | true | *null*

## Response

Possibly No Response

