<?php

function ColorWhite(float $Alpha = 100)
{
	return new pChart\pColor(255,255,255,$Alpha);
}

function ColorBlack(float $Alpha = 100)
{
	return new pChart\pColor(0,0,0,$Alpha);
}

?>